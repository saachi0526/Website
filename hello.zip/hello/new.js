angular.module('profileApp', [])
    .controller('ProfileController', function($scope) {
        // Predefined profiles
        $scope.profiles = [
            { name: "Sandhya Shekar", description: "If you're looking for festive and wedding makeup inspiration,Even if she's adding colour—through a copper eyeshadow or a hint of blush—Shekar goes the no makeup-makeup route.", photoUrl: "l.jpg", location: "Pune,+Maharashtra/Survey+No+2,+Vishwakarma+University,+3,4,+Kondhwa+Main+Rd,+Laxmi+Nagar,+Betal+Nagar,+Kondhwa,+Pune,+Maharashtra+411048/@18.4904813,73.8286728,13z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x3bc2bf2e67461101:0x828d43bf9d9ee343!2m2!1d73.8567437!2d18.5204303!1m5!1m1!1s0x3bc2eaf42e26fa71:0x2a9a1928beae9eec!2m2!1d73.8835829!2d18.460303!3e0?entry=ttu" },
            { name: "Mickey Contractor", description: "“My idea of beauty is simplicity, elegance, something that is flattering and not necessarily over the top.", photoUrl: "l1.jpg", location: "New+Delhi,+India" },
            { name: "Arti Nayar", description: "She might be wielding her brushes on celebrities like Sonam Kapoor Ahuja and Katrina Kaif when she's on the clock, but she likes to try something bold and creative on herself often too.", photoUrl: "l3.jpg", location: "Mumbai,+Maharashtra" },
            { name: "Namrata Soni", description: "Namrata Soni is a makeup pro who is known for her famous #NamGlow—bright, lit-from-within skin that looks luminous rather than shiny.", photoUrl: "l4.jpg", location: "Bangalore,+Karnataka" },
            { name: "Puneeta B Saini", description: "I think we need to remember that a balanced look always looks more appealing. However, having said that, there's no rule against going all out bold.", photoUrl: "l5.jpg", location: "Hyderabad,+Telangana" },
            { name: "Vardana Nayak", description: "You'll see cream contour and a hint of blush on all his most double-tapped looks, and for good reason,The romantic smoky eye.", photoUrl: "l6.jpg", location: "Chennai,+Tamil+Nadu" },
            { name: "Lekha Gupta", description: "Lekha Gupta is the makeup artist behind some of Madhuri Dixit Nene's boldest makeup moments, proving that even as you get older.", photoUrl: "l7.jpg", location: "Kolkata,+West+Bengal" },
            { name: "Mehak Oberoi", description: "She loves using bright colours and glitters to amp up what she creates, especially on actors like Sonakshi Sinha, Malaika Arora", photoUrl: "l9.jpg", location: "Ahmedabad,+Gujarat" }
        ];

        // Function to add a new profile
        $scope.addProfile = function() {
            var fileInput = document.createElement("input");
            fileInput.type = "file";
            fileInput.accept = "image/*";
            fileInput.addEventListener("change", function(event) {
                $scope.handleFileSelect(event, function(photoUrl) {
                    var name = prompt("Enter name:");
                    var description = prompt("Enter description:");
                    var location = prompt("Enter location:");
                    $scope.addNewProfile(name, description, photoUrl, location);
                });
            });
            fileInput.click();
        };

        // Function to handle file input change
        $scope.handleFileSelect = function(event, callback) {
            var files = event.target.files;
            var file = files[0];
            var reader = new FileReader();
            reader.onload = function(event) {
                var photoUrl = event.target.result;
                callback(photoUrl);
            };
            reader.readAsDataURL(file);
        };

        // Function to add a new profile to the list
        $scope.addNewProfile = function(name, description, photoUrl, location) {
            $scope.profiles.push({ name: name, description: description, photoUrl: photoUrl, location: location });
            $scope.$apply(); // Ensure data binding updates
        };

        // Function to delete a profile
        $scope.deleteProfile = function() {
            var profileToDelete = prompt("Enter the name of the profile to delete:");
            var index = -1;

            $scope.profiles.forEach(function(profile, i) {
                if (profile.name === profileToDelete) {
                    index = i;
                    return; // Exit the loop if found
                }
            });

            if (index !== -1) {
                $scope.profiles.splice(index, 1);
            } else {
                alert("Profile not found.");
            }
        };

        // Function to edit a profile
        $scope.editProfile = function() {
            var profileToEdit = prompt("Enter the name of the profile to edit:");
            $scope.profiles.forEach(function(profile) {
                if (profile.name === profileToEdit) {
                    var newName = prompt("Enter the new name:");
                    var newDescription = prompt("Enter the new description:");
                    var newLocation = prompt("Enter the new location:");
                    profile.name = newName;
                    profile.description = newDescription;
                    profile.location = newLocation;
                }
            });
        };
    });
