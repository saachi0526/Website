var app = angular.module('profileApp', ['ngRoute']);

app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'login.html',
            controller: 'LoginController'
        })
        .when('/profile', {
            templateUrl: 'profile.html',
            controller: 'ProfileController'
        })
        .otherwise({
            redirectTo: '/'
        });
});

app.controller('LoginController', function($scope, $location) {
    $scope.login = function() {
        // Check login credentials
        var username = $scope.username;
        var password = $scope.password;

        // Assuming successful login for demonstration purposes
        if (username === 'admin' && password === 'password') {
            // Redirect to index.html upon successful login
            window.location.href = 'new.html';
        } else {
            alert('Invalid username or password');
        }
    };
});

app.controller('ProfileController', function($scope) {
    // Your profile controller logic goes here
});
